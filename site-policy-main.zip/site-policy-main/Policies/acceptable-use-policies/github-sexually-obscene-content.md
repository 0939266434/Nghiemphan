---
title: GitHub Sexually Obscene Content
shortTitle: Sexually Obscene Content
versions:
  fpt: '*'
topics:
  - Policy
  - Legal
redirect_from:
  - /github/site-policy/github-sexually-obscene-content
  - /github/site-policy/github-community-guidelines#sexually-obscene-content
---

We do not tolerate content associated with sexual exploitation or abuse of another individual, including where minors are concerned. We do not allow sexually themed or suggestive content that serves little or no purpose other than to solicit an erotic or shocking response, particularly where that content is amplified by its placement in profiles or other social contexts. This includes:

- Pornographic content
- Non-consensual intimate imagery
- Graphic depictions of sexual acts including photographs, video, animation, drawings, computer-generated images, or text-based content

We recognize that not all nudity or content related to sexuality is obscene. We may allow visual and/or textual depictions in artistic, educational, historical or journalistic contexts, or as it relates to victim advocacy. In some cases a disclaimer can help communicate the context of the project. However, please understand that we may choose to limit the content by giving users the option to opt in before viewing.
